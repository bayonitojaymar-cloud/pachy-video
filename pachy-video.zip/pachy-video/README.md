# Pachy Video

3D (Three.js) + captions/audio/rendering (Remotion).

## Run it (online editor or your computer)
Requires Node 18+.

1. Unzip and open the folder (or upload it to StackBlitz / CodeSandbox / Replit / GitHub Codespaces).
2. Install: `npm install`
3. Preview: `npm run dev` (opens Remotion Studio, pick the `PachyVideo` composition)
4. Render video: `npm run render` -> `out/pachy.mp4`
5. Thumbnail: `npm run still` -> `out/thumb.png`

Note: Remotion Studio previews fine in most online editors, but rendering needs
headless Chrome. If `npm run render` fails in a browser-based editor, render on
your computer or in Codespaces/Replit instead.

## Where things go
- `src/index.ts`: registers the Remotion root
- `src/Root.tsx`: registers the `PachyVideo` composition (1080x1920, 30 fps, 12 s)
- `src/Scene.tsx`: the 3D scene (placeholder Pachycephalosaurus from primitives)
- `src/captions.ts`: captions with start/end in ms
- `src/Captions.tsx`: caption styling and animation
- `src/PachyVideo.tsx`: combines scene, captions and audio
- `public/voiceover.mp3`: your narration. Then set `HAS_VOICEOVER = true` in `PachyVideo.tsx`
- Music/SFX: drop in `public/` and add more `<Audio>` tags

## Swapping in a real 3D model
Put a `.glb` in `public/`, then in `Scene.tsx` use `useGLTF` from `@react-three/drei`
(`npm i @react-three/drei@^9`) and `staticFile("pachy.glb")`.
