import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import type { Caption } from "@remotion/captions";

export const Captions: React.FC<{ captions: Caption[] }> = ({ captions }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const nowMs = (frame / fps) * 1000;

  const active = captions.find((c) => nowMs >= c.startMs && nowMs < c.endMs);
  if (!active) return null;

  const localFrame = ((nowMs - active.startMs) / 1000) * fps;
  const scale = interpolate(localFrame, [0, 5], [0.85, 1], {
    extrapolateRight: "clamp",
  });
  const opacity = interpolate(localFrame, [0, 4], [0, 1], {
    extrapolateRight: "clamp",
  });

  return (
    <div
      style={{
        position: "absolute",
        bottom: 260,
        left: 60,
        right: 60,
        textAlign: "center",
        fontFamily: "Impact, Arial Black, sans-serif",
        fontSize: 88,
        lineHeight: 1.1,
        color: "white",
        textTransform: "uppercase",
        WebkitTextStroke: "6px black",
        paintOrder: "stroke fill",
        transform: `scale(${scale})`,
        opacity,
      }}
    >
      {active.text.trim()}
    </div>
  );
};
