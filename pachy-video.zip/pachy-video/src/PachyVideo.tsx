import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import type { Caption } from "@remotion/captions";
import { Scene } from "./Scene";
import { Captions } from "./Captions";

// Set to true after you drop a file at public/voiceover.mp3
const HAS_VOICEOVER = false;

export const PachyVideo: React.FC<{ captions: Caption[] }> = ({ captions }) => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#87b7d9" }}>
      <Scene />
      <Captions captions={captions} />
      {HAS_VOICEOVER && <Audio src={staticFile("voiceover.mp3")} />}
    </AbsoluteFill>
  );
};
