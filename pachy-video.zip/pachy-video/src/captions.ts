import type { Caption } from "@remotion/captions";

// Word/phrase-level captions. Times are in milliseconds.
// Replace with captions generated from your real voiceover later.
export const captions: Caption[] = [
  { text: "Being a Pachycephalosaurus", startMs: 0, endMs: 2500, timestampMs: null, confidence: null },
  { text: " sucks.", startMs: 2500, endMs: 4000, timestampMs: null, confidence: null },
  { text: " Your whole personality", startMs: 4000, endMs: 6500, timestampMs: null, confidence: null },
  { text: " is a thick skull.", startMs: 6500, endMs: 8500, timestampMs: null, confidence: null },
  { text: " And everyone wants to headbutt.", startMs: 8500, endMs: 12000, timestampMs: null, confidence: null },
];
