import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { ThreeCanvas } from "@remotion/three";

// Simple stylized Pachycephalosaurus placeholder built from primitives.
// Swap this for a GLB model later (see README).
const Pachy: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;

  // Repeated headbutt motion
  const headbutt = Math.max(0, Math.sin(t * 4)) * 0.5;
  const bob = Math.sin(t * 2) * 0.05;

  return (
    <group position={[0, bob - 0.5, 0]} rotation={[0, -0.5, 0]}>
      {/* body */}
      <mesh position={[0, 0, 0]} scale={[1.6, 1, 1]}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial color="#7a8f4a" />
      </mesh>
      {/* tail */}
      <mesh position={[-2, -0.1, 0]} rotation={[0, 0, Math.PI / 2 + 0.2]}>
        <coneGeometry args={[0.5, 2.4, 24]} />
        <meshStandardMaterial color="#7a8f4a" />
      </mesh>
      {/* neck */}
      <mesh position={[1.4, 0.7, 0]} rotation={[0, 0, -0.6]}>
        <cylinderGeometry args={[0.35, 0.5, 1.2, 24]} />
        <meshStandardMaterial color="#7a8f4a" />
      </mesh>
      {/* head + dome */}
      <group position={[2 + headbutt, 1.2, 0]}>
        <mesh>
          <sphereGeometry args={[0.55, 32, 32]} />
          <meshStandardMaterial color="#8da35a" />
        </mesh>
        <mesh position={[0.05, 0.35, 0]}>
          <sphereGeometry args={[0.45, 32, 32]} />
          <meshStandardMaterial color="#d8c9a0" />
        </mesh>
        {/* sad eye */}
        <mesh position={[0.35, 0.1, 0.35]}>
          <sphereGeometry args={[0.08, 16, 16]} />
          <meshStandardMaterial color="black" />
        </mesh>
      </group>
      {/* legs */}
      {[-0.5, 0.6].map((x, i) => (
        <mesh key={i} position={[x, -1.1, 0.3]}>
          <cylinderGeometry args={[0.2, 0.25, 1, 16]} />
          <meshStandardMaterial color="#657a3c" />
        </mesh>
      ))}
    </group>
  );
};

export const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height, durationInFrames } = useVideoConfig();
  const camX = interpolate(frame, [0, durationInFrames], [-1, 1]);

  return (
    <ThreeCanvas
      width={width}
      height={height}
      camera={{ position: [camX, 1, 7], fov: 50 }}
    >
      <ambientLight intensity={0.7} />
      <directionalLight position={[5, 8, 5]} intensity={1.4} />
      <Pachy />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.7, 0]}>
        <planeGeometry args={[40, 40]} />
        <meshStandardMaterial color="#b89968" />
      </mesh>
    </ThreeCanvas>
  );
};
