import React from "react";
import { Composition } from "remotion";
import { PachyVideo } from "./PachyVideo";
import { captions } from "./captions";

export const FPS = 30;
export const DURATION_SECONDS = 12;

export const Root: React.FC = () => {
  return (
    <Composition
      id="PachyVideo"
      component={PachyVideo}
      durationInFrames={FPS * DURATION_SECONDS}
      fps={FPS}
      width={1080}
      height={1920}
      defaultProps={{ captions }}
    />
  );
};
